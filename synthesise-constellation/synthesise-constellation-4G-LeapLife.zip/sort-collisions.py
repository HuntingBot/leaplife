#sort-collisions.py
# Read in unsorted glider collisions lines from all files on command line
# Output sorted collisions to first file in synthesise-constellation.py format
# Collisions are in a modified version of Shinjuku's component format:
#   - single line containing apgcode of output constellation, followed by
#   - multiple lines containing components producing that constellation with
#     the out_apgcode omitted
# Input files can be in either format

# For Python3 print function
from __future__ import print_function

import sys
import shutil
import lifelib

if len(sys.argv) == 1:
  print("  Usage: python sort-collisions.py <cols-file.sjk> <cols-extra.sjk> ...")
  sys.exit()

inFiles = sys.argv[1:]
outFile = inFiles[0]

lt = lifelib.load_rules('b2n3s23-q').lifetree(memory=8000)

glidercols = {}
results = set()

i = 0
for filename in inFiles:
  with open(filename) as Fin:
    apgcode = ""
    test_pop = True
    
    for l in Fin:
      line = l.strip()
      if not line:
        continue
      i += 1
      if (i % 10000) == 0:
        print(".", end='')
        sys.stdout.flush()
      
      if ">" in line:
        in_code, gstr, result = line.split('>')
        if result:
          apgcode = result
      else:
        apgcode = line
        gstr = ""
        test_pop = True
        continue
      line = "{}>{}>\n".format(in_code, gstr)
      try:
        glidercols[apgcode].append(line)
      except KeyError:
        glidercols[apgcode] = [line]
        # Calculate the population for previously unseen objects
        if apgcode.startswith("xs"):
          pop = int(apgcode[2:apgcode.find("_")])
        else:
          pat = lt.pattern(apgcode)
          pop = pat.population
        results.add((apgcode, pop))

results = sorted(results, key=lambda x: x[1])

tempFile = outFile + ".bak"
with open(tempFile, 'w') as Fout:
  for result in results:
    apgcode = result[0]
    print(apgcode, file=Fout)
    Fout.writelines(glidercols[apgcode])

shutil.move(tempFile, outFile)

print("")
